This is a Admin Ped Menu that only the certain job ones can open or else should can not open

You Can Configure this script through `config.lua` And Also You Can Change the name of title and option in `client.lua`

This Requires The `Ox_lib` 

You Can Download It From https://github.com/overextended/ox_lib