Config = {}

-- Head Admins
Config.PedDeadPool = ''
Config.PedBlackPanther = ''
Config.PedIronMan = ''  -- Head Admin Side Peds spawn name
Config.PedThor = ''
Config.PedSpiderman = ''

-- Staff Peds
Config.PedStaff = '' -- Staff side ped spawn name

-- Admin Job ( Access Job )
Config.AccessJob = '' -- job name
